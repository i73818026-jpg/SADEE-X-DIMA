package com.sadeedima.admin

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

object KeyGenerator {
    // DEMO/OFFLINE ONLY. For production, generate/sign keys on a server.
    private const val SECRET = "SADEE_X_DIMA_DEMO_2026_CHANGE_ME"
    private const val PREFS = "keys"

    fun generate(context: Context, days: Int?): String {
        val expiry = if (days == null) 0L
        else System.currentTimeMillis() + days * 24L * 60L * 60L * 1000L

        val expiry36 = expiry.toString(36).uppercase().padStart(8, '0')
        val nonce = UUID.randomUUID().toString().replace("-", "").take(4).uppercase()
        val checksum = sha256("$expiry36:$nonce:$SECRET").take(6).uppercase()
        val key = "SDX-$expiry36-$nonce-$checksum"

        val old = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("history", "").orEmpty()
        val line = "$key|${days ?: "LIFETIME"}|$expiry\n"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("history", old + line).apply()
        return key
    }

    fun history(context: Context): List<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("history", "")
            .orEmpty().lines().filter { it.isNotBlank() }.reversed()

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
