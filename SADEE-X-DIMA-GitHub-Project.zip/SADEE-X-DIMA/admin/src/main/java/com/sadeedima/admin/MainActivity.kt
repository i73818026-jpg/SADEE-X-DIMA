package com.sadeedima.admin

import android.app.*
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var historyBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,28,24,24)
            setBackgroundColor(Color.rgb(7,7,10))
        }
        scroll.addView(root)
        root.addView(text("SADEE X DIMA", 30f, Color.WHITE))
        root.addView(text("ADMIN PANEL", 18f, Color.rgb(255,40,40)))
        root.addView(text("License Key Generator", 16f, Color.LTGRAY))

        val durations = listOf(
            "1 DAY" to 1, "3 DAYS" to 3, "5 DAYS" to 5, "7 DAYS" to 7,
            "14 DAYS" to 14, "30 DAYS" to 30, "LIFETIME" to null
        )
        durations.forEach { (label, days) ->
            root.addView(button("GENERATE $label") {
                val key = KeyGenerator.generate(this, days)
                showKey(key, label)
                refreshHistory()
            })
        }

        root.addView(text("KEY HISTORY", 19f, Color.WHITE).apply { setPadding(0,24,0,10) })
        historyBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(historyBox)
        refreshHistory()
        setContentView(scroll)
    }

    private fun showKey(key: String, plan: String) {
        val input = EditText(this).apply {
            setText(key); setTextIsSelectable(true); setSingleLine()
        }
        AlertDialog.Builder(this).setTitle("$plan KEY GENERATED")
            .setMessage("Copy this key into the Optimizer app.")
            .setView(input)
            .setPositiveButton("COPY") { _, _ ->
                val clip = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clip.setPrimaryClip(android.content.ClipData.newPlainText("SADEE X DIMA Key", key))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("CLOSE", null).show()
    }

    private fun refreshHistory() {
        if (!::historyBox.isInitialized) return
        historyBox.removeAllViews()
        KeyGenerator.history(this).forEach { line ->
            val p = line.split("|")
            val key = p.getOrNull(0) ?: return@forEach
            val plan = p.getOrNull(1) ?: "?"
            val expiry = p.getOrNull(2)?.toLongOrNull() ?: 0L
            val date = if (expiry == 0L) "No expiry" else SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(expiry))
            historyBox.addView(text("$key\nPlan: $plan   Expiry: $date", 14f, Color.WHITE).apply {
                setPadding(14,14,14,14)
                setBackgroundColor(Color.rgb(25,25,30))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,0,0,8) }
            })
        })
    }

    private fun text(s:String, size:Float, color:Int) = TextView(this).apply {
        text=s; textSize=size; setTextColor(color)
    }
    private fun button(s:String, action:()->Unit) = Button(this).apply {
        text=s; textSize=14f; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(45,20,20))
        setOnClickListener { action() }
        layoutParams=LinearLayout.LayoutParams(-1,58).apply{setMargins(0,10,0,0)}
    }
}
