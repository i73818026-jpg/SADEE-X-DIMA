package com.sadeedima.optimizer

import android.content.Context
import java.security.MessageDigest

object LicenseManager {
    private const val PREFS = "license"
    private const val KEY = "active_key"
    private const val SECRET = "SADEE_X_DIMA_DEMO_2026_CHANGE_ME"

    fun saveKey(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, key.trim()).apply()
    }

    fun getKey(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)

    fun validate(key: String, now: Long = System.currentTimeMillis()): Result {
        val parts = key.trim().split("-")
        if (parts.size != 4 || parts[0] != "SDX") return Result(false, "Invalid key format")
        val expiry = parts[1].toLongOrNull(36) ?: return Result(false, "Invalid key")
        val checksum = parts[3]
        val expected = sha256("${parts[1]}:${parts[2]}:$SECRET").take(6).uppercase()
        if (checksum != expected) return Result(false, "Invalid key")
        if (expiry != 0L && now >= expiry) return Result(false, "Key expired")
        return Result(true, if (expiry == 0L) "LIFETIME" else "ACTIVE")
    }

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray())
            .joinToString("") { "%02x".format(it) }

    data class Result(val active: Boolean, val message: String)
}
