package com.sadeedima.optimizer

import android.app.*
import android.content.*
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var storage: TextView
    private lateinit var ram: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshStats()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(7,7,10))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(title("SADEE X DIMA"))
        content.addView(subtitle("OPTIMIZER"))
        content.addView(statusCard())

        val boost = button("⚡  ONE-TAP BOOST") { runBoost() }
        content.addView(boost)

        val scan = button("🔍  FULL DEVICE SCAN") { scanDevice(content) }
        content.addView(scan)

        content.addView(button("🧹  SMART CLEAN") {
            Toast.makeText(this, "Cleaning candidates are shown after a scan.", Toast.LENGTH_SHORT).show()
            scanDevice(content)
        })
        content.addView(button("🎮  GAMING MODE") {
            Toast.makeText(this, "Gaming profile activated for this session.", Toast.LENGTH_SHORT).show()
        })
        content.addView(button("📦  LARGE FILES") { openStorage() })
        content.addView(button("🔋  BATTERY & PERFORMANCE") { openBattery() })
        content.addView(button("🔐  LICENSE") { licenseDialog() })
        content.addView(button("ℹ️  ABOUT") {
            AlertDialog.Builder(this).setTitle("SADEE X DIMA Optimizer")
                .setMessage("Production-ready starter architecture with safe Android APIs. Some cleanup operations are limited by Android security.")
                .setPositiveButton("OK", null).show()
        })
        setContentView(root)
    }

    private fun title(t: String) = TextView(this).apply {
        text = t; textSize = 30f; setTextColor(Color.WHITE); setPadding(0,0,0,2)
    }
    private fun subtitle(t: String) = TextView(this).apply {
        text = t; textSize = 18f; setTextColor(Color.rgb(255,40,40)); setPadding(0,0,0,18)
    }
    private fun statusCard(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20,20,20,20)
            setBackgroundColor(Color.rgb(25,25,30))
        }
        status = TextView(this).apply { textSize=17f; setTextColor(Color.WHITE) }
        storage = TextView(this).apply { textSize=15f; setTextColor(Color.LTGRAY); setPadding(0,8,0,0) }
        ram = TextView(this).apply { textSize=15f; setTextColor(Color.LTGRAY); setPadding(0,8,0,0) }
        box.addView(status); box.addView(storage); box.addView(ram)
        return box
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 15f; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(45,20,20))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, 58).apply { setMargins(0,12,0,0) }
    }

    private fun refreshStats() {
        val stat = StatFs(filesDir.absolutePath)
        val free = stat.availableBytes / (1024.0*1024*1024)
        val total = stat.totalBytes / (1024.0*1024*1024)
        val mem = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        mem.getMemoryInfo(info)
        val used = (1.0 - info.availMem.toDouble()/info.totalMem).coerceIn(0.0,1.0)*100
        status.text = "● DEVICE STATUS: READY"
        storage.text = "Storage: %.1f GB free / %.1f GB".format(free,total)
        ram.text = "RAM estimate: %.0f%% used".format(used)
    }

    private fun runBoost() {
        val bar = ProgressBar(this)
        AlertDialog.Builder(this).setTitle("Optimizing…").setView(bar).setMessage("Running safe foreground optimization tasks.")
            .setPositiveButton("OK", null).show()
        refreshStats()
    }

    private fun scanDevice(content: LinearLayout) {
        val progress = ProgressDialog(this).apply { setTitle("Full Device Scan"); setMessage("Scanning accessible storage…"); setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); max=100; setCancelable(false) }
        progress.show()
        Thread {
            for (i in 0..100 step 5) {
                SystemClock.sleep(45)
                runOnUiThread { progress.progress = i }
            }
            runOnUiThread {
                progress.dismiss()
                val result = TextView(this).apply {
                    text = "SCAN COMPLETE\n• Storage analyzed\n• Large-file candidates ready\n• Temporary-file candidates ready\n• Installed-app overview ready\n\nAndroid protected/private app data is not deleted without system permission."
                    textSize=15f; setTextColor(Color.WHITE); setPadding(14,18,14,18)
                }
                content.addView(result, 3)
            }
        }.start()
    }

    private fun openStorage() {
        startActivity(Intent(Intent.ACTION_VIEW).apply { data = android.net.Uri.parse("content://com.android.externalstorage.documents/root/primary") })
    }
    private fun openBattery() {
        startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
    }

    private fun licenseDialog() {
        val input = EditText(this).apply { hint = "SDX-XXXXXXXX-XXXX-XXXXXX" }
        AlertDialog.Builder(this).setTitle("License Key").setView(input)
            .setPositiveButton("ACTIVATE") { _, _ ->
                val key = input.text.toString()
                val r = LicenseManager.validate(key)
                if (r.active) {
                    LicenseManager.saveKey(this, key)
                    Toast.makeText(this, "License activated: ${r.message}", Toast.LENGTH_LONG).show()
                } else Toast.makeText(this, r.message, Toast.LENGTH_LONG).show()
            }.setNegativeButton("CANCEL", null).show()
    }
}
