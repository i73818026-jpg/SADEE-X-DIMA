# SADEE X DIMA Optimizer + Admin

Two Android apps in one GitHub repository:

- `optimizer` — SADEE X DIMA Optimizer
- `admin` — SADEE X DIMA Admin Panel

## Build on GitHub

1. Create a GitHub repository.
2. Upload all files while preserving folders.
3. Open **Actions**.
4. Run **Build SADEE X DIMA Optimizer** or **Build SADEE X DIMA Admin**.
5. Download the generated APK from the workflow's **Artifacts** section.

## Important Android limits

A normal Android app cannot silently delete another app's private data/cache or change protected system settings. This project uses safe Android APIs and presents scan/cleanup candidates rather than pretending it has unrestricted system access.

## License system

The included key system is an **offline demo implementation** so the two APKs can be tested without a server.

For a real commercial release:
- move license generation/signing to a backend,
- use asymmetric signatures (private key server-side, public key inside the optimizer),
- validate expiry against trusted server time,
- bind keys to accounts/devices if desired,
- never embed a production private secret in the APK.

## Branding

The supplied SADEE X DIMA artwork is stored as:

`optimizer/src/main/res/drawable-nodpi/sadee_x_dima_optimizer.png`

and can be used for splash/branding screens. The same asset is also copied to the admin module.
